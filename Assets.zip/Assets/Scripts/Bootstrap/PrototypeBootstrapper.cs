using TMPro;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;

public class PrototypeBootstrapper : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void AutoBootstrap()
    {
        if (FindFirstObjectByType<PrototypeBootstrapper>() != null) return;
        new GameObject("PrototypeBootstrapper").AddComponent<PrototypeBootstrapper>();
    }

    private void Awake()
    {
        Application.targetFrameRate = 120;
        SetupScene();
    }

    private void SetupScene()
    {
        CreateEventSystemIfMissing();
        SetupSpriteRegistry();
        SetupPlacementValidator();
        SetupCameraAndBackground(out Camera mainCamera);
        SetupTilemap();

        var gameController = new GameObject("GameController").AddComponent<PrototypeGameController>();

        // Look for UIController in scene (Mislav sets up Canvas + references).
        // Until then, create everything from code as before.
        var uiController = FindFirstObjectByType<PrototypeUIController>();
        if (uiController == null)
            uiController = CreateFallbackUI(gameController, mainCamera);
        else
            uiController.Build(gameController, mainCamera);

        Sprite workerSprite = SimpleShapeFactory.CreateFilledTriangleSprite(new Color(1f, 0.9f, 0.25f, 1f));
        var townHallPos     = FindTownHallPosition();
        gameController.Initialize(uiController, workerSprite, townHallPos);

        CreateTownHall(gameController, townHallPos);

        var selection = new GameObject("SelectionController").AddComponent<PrototypeSelectionController>();
        selection.Initialize(gameController, mainCamera);

        // Team managers self-register via RuntimeInitializeOnLoadMethod
    }

    // ---- Fallback UI (code-generated, used until Mislav sets up scene) ----

    private PrototypeUIController CreateFallbackUI(PrototypeGameController game, Camera cam)
    {
        var canvasGO = new GameObject("Canvas");
        var canvas   = canvasGO.AddComponent<Canvas>();
        canvas.renderMode   = RenderMode.ScreenSpaceOverlay;
        canvas.pixelPerfect = true;

        var scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 720);
        scaler.screenMatchMode     = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight  = 0.5f;
        canvasGO.AddComponent<GraphicRaycaster>();

        var ui = canvasGO.AddComponent<PrototypeUIController>();
        ui.BuildFromCode(game, canvas.transform, cam);
        return ui;
    }

    // ---- Tilemap ----

    private void SetupTilemap()
    {
        var map = Resources.Load<TilemapData>("IslandMap");
        if (map == null)
        {
            map = ScriptableObject.CreateInstance<TilemapData>();
            map.GeneratePlaceholder();
            Debug.LogWarning(
                "[Bootstrapper] IslandMap.asset not found in Assets/Resources/. " +
                "Create via Assets > Create > Ashes > TilemapData, " +
                "draw the map, then move to Assets/Resources/IslandMap.asset");
        }

        var go       = new GameObject("IslandTilemap");
        var renderer = go.AddComponent<IslandTilemapRenderer>();
        renderer.Initialize(map);
    }

    // ---- Sprite Registry ----

    private void SetupSpriteRegistry()
    {
        var registry = Resources.Load<SpriteRegistry>("SpriteRegistry");
        if (registry != null)
        {
            registry.Register();
        }
        else
        {
            Debug.LogWarning(
                "[Bootstrapper] SpriteRegistry.asset not found in Assets/Resources/. " +
                "Create via Assets > Create > Ashes > SpriteRegistry " +
                "and move to Assets/Resources/SpriteRegistry.asset");
        }
    }

    // ---- Placement Validator ----

    private void SetupPlacementValidator()
    {
        new GameObject("PlacementValidator").AddComponent<PlacementValidator>();
    }

    // ---- Town Hall ----

    /// <summary>
    /// Finds the nearest Land tile to the map centre for Town Hall placement.
    /// Falls back to world origin if no Land tile found (should never happen).
    /// </summary>
    private static Vector3 FindTownHallPosition()
    {
        var renderer = IslandTilemapRenderer.Instance;
        if (renderer == null || renderer.Map == null)
            return new Vector3(-3.5f, -1.8f, 0f); // fallback

        var map   = renderer.Map;
        int cx    = map.Width  / 2;
        int cy    = map.Height / 2;
        int best  = int.MaxValue;
        int bestC = cx, bestR = cy;

        // Spiral outward from centre to find nearest Land tile
        for (int radius = 0; radius < Mathf.Max(map.Width, map.Height); radius++)
        for (int row = cy - radius; row <= cy + radius; row++)
        for (int col = cx - radius; col <= cx + radius; col++)
        {
            if (!map.InBounds(col, row)) continue;
            if (map.GetTile(col, row) != TileType.Land) continue;
            int dist = (col - cx) * (col - cx) + (row - cy) * (row - cy);
            if (dist < best) { best = dist; bestC = col; bestR = row; }
        }

        var world = map.TileToWorld(bestC, bestR);
        return new Vector3(world.x, world.y, 0f);
    }

    

    private void CreateTownHall(PrototypeGameController game, Vector3 position)
    {
        var go       = new GameObject("TownHall");
        var building = go.AddComponent<BuildingInstance>();
        building.Initialize(game, "Town Hall", ResourceType.Wood,
            new Color(0.72f, 0.58f, 0.22f), position,
            new Vector2(1.0f, 1.0f), false);
        building.SetTownHall(true);
        game.RegisterBuilding(building);

        var lbl = new GameObject("TownHallLabel");
        lbl.transform.SetParent(go.transform, false);
        lbl.transform.localPosition = new Vector3(0f, 0.65f, 0f);
        var tmp = lbl.AddComponent<TextMeshPro>();
        tmp.text        = "Town Hall";
        tmp.fontSize    = 1.8f;
        tmp.alignment   = TextAlignmentOptions.Center;
        tmp.color       = Color.white;
        tmp.rectTransform.sizeDelta = new Vector2(4f, 1f);
        tmp.sortingOrder = 20;
    }

    // ---- Camera + Ocean background ----

    private void SetupCameraAndBackground(out Camera mainCamera)
    {
        var cameraObject = new GameObject("Main Camera");
        mainCamera = cameraObject.AddComponent<Camera>();
        cameraObject.tag             = "MainCamera";
        mainCamera.clearFlags        = CameraClearFlags.SolidColor;
        mainCamera.backgroundColor   = new Color(0.09f, 0.28f, 0.52f, 1f);
        mainCamera.orthographic      = true;
        mainCamera.orthographicSize  = 10f;
        cameraObject.transform.position = new Vector3(0f, 0f, -15f);
        cameraObject.AddComponent<AudioListener>();
        cameraObject.AddComponent<PrototypeCameraController>();

        // Ocean background quad — sits behind tilemap
        var ocean   = new GameObject("Ocean");
        var oceanSR = ocean.AddComponent<SpriteRenderer>();
        oceanSR.sprite = SimpleShapeFactory.CreateFilledSquareSprite(new Color(0.09f, 0.28f, 0.52f, 1f));
        oceanSR.sortingOrder = -20;
        ocean.transform.localScale = new Vector3(80f, 60f, 1f);
    }

    // ---- Event System ----

    private void CreateEventSystemIfMissing()
    {
        if (FindFirstObjectByType<EventSystem>() != null) return;
        var es = new GameObject("EventSystem");
        es.AddComponent<EventSystem>();
        es.AddComponent<InputSystemUIInputModule>();
    }
}
